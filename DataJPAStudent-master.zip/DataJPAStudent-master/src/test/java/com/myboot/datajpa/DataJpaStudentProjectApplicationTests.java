package com.myboot.datajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaStudentProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
