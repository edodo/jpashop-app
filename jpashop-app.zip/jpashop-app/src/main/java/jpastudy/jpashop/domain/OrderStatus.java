package jpastudy.jpashop.domain;

public enum OrderStatus {
	ORDER, CANCEL
}
